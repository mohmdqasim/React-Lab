/**
 * Example API Service
 * Each entity will have it's own API Service
 * Auth is separated from other API Services
 */
import { api } from "./core";

/**
 * Import Setters and Getters from the Global Slice for each entity you want access to globally in the application
 * import { setLanguage, setUser } from "../slices/global";
 */

export const authApi = api.injectEndpoints({
  endpoints: (build) => ({
    login: build.mutation({
      query: (credentials) => ({
        url: "/login",
        method: "POST",
        body: credentials,
      }),
      async onQueryStarted(_, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(() => {});
          // dispatch(setUser(data.data));

          if (data.data.role_id === "2") {
            // dispatch(setLanguage("1"));
          }

          if (data.data.role_id === "3") {
            // dispatch(setLanguage("2"));
          }

          if (data.data.role_id === "4") {
            // dispatch(setLanguage("3"));
          }
        } catch (error: Error | any) {
          throw new Error(error);
        }
      },
    }),
    fetchUser: build.query({
      query: (id) => ({
        url: `/user?id=${id}`,
        method: "GET",
      }),
      providesTags: [],
    }),
  }),
});

export const { useLoginMutation } = authApi;
