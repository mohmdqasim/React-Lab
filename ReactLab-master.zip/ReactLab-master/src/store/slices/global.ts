import { createSlice } from "@reduxjs/toolkit";

const initialState: GlobalStateProps = {
  count: 0,
};

const globalSlice = createSlice({
  name: "global",
  initialState,
  reducers: {
    incrementCount: (state) => {
      state.count += 1;
    },
    decrementCount: (state) => {
      state.count -= 1;
    },
  },
});

export const { incrementCount, decrementCount } = globalSlice.actions;
export default globalSlice.reducer;
