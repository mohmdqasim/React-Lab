declare type StripePaySession = {
  id: string;
};

declare type GlobalStateProps = {
  count: number;
};
