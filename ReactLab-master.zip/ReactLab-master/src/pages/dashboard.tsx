import { useDispatch, useSelector } from "react-redux";

import { Button } from "@/components/ui/button";
import { RootState } from "@/store";
import { decrementCount, incrementCount } from "@/store/slices/global";

const Dashboard = () => {
  const dispatch = useDispatch();
  const { count } = useSelector((state: RootState) => state.global);

  const incrementCounter = () => {
    dispatch(incrementCount());
  };

  const decrementCounter = () => {
    dispatch(decrementCount());
  };

  return (
    <div className="flex h-full w-full items-center justify-center rounded-xl bg-muted">
      <div className="flex flex-col items-center justify-center gap-5">
        <span className="w-full text-center text-4xl font-bold">
          Global Count: {count}
        </span>
        <div className="flex items-center justify-center gap-5">
          <Button
            type="button"
            variant="default"
            size="lg"
            onClick={incrementCounter}
          >
            Increment
          </Button>
          <Button
            type="button"
            variant="destructive"
            size="lg"
            onClick={decrementCounter}
          >
            Decrement
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
